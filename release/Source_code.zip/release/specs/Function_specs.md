## Description of BlockPig

## CurrencyDescription

The Currency pallet handles logic for create new currency, update balance, and transfer.